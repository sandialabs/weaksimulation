void extend(int n, int *k, int *h, int **G, int **GBar, int *xi);
