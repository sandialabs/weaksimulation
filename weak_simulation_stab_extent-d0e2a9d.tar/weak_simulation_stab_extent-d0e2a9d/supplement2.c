#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

void printBinary(unsigned long number, int T) {

  int i;
  
  for(i=0; i<T; i++)
    printf("%d", (int)(number/pow(2,i))%2);
  printf("\n");
  
}

void supplement2(long stabStateIndices[], int T, double fractionSupplement)
{

  int bitstringCounterMax = floor(fractionSupplement*(2*T-1));
  if(bitstringCounterMax < 1)
    return;

  int K = round(log(T)/log(2)); // T = 2^K

  //printf("K=%d\n", K);

  unsigned long given = (unsigned long)stabStateIndices[0]; // the given bitstring

  //printf("given bitstring =");
  //printBinary(stabStateIndices[0], T);

  unsigned long long precurserBitstrings[2*T-1];
  unsigned long long tmpBitstrings[2*T-1];

  int precurserBitstringCounter = 0;

  int i, j, k;

  // first added bitstring is alpha = 10
  precurserBitstrings[0] = 2;
  //printf("added precurser=");
  //printBinary(precurserBitstrings[0], T);
  // second added bitstring is beta = 01
  precurserBitstrings[1] = 1;
  //printf("added precurser=");
  //printBinary(precurserBitstrings[1], T);
  // third added bitstring is gamma = 11
  precurserBitstrings[2] = 0;
  //printf("added precurser=");
  //printBinary(precurserBitstrings[2], T);
  precurserBitstringCounter+=3;

  long mask;
  for(i=1; i<=K-1; i++) {
    mask = 0;
    for(j=0;j<pow(2,i-1);j++)
      mask += 3*pow(2,2*j+pow(2,i));
    //printf("mask=");
    //printBinary(mask, T);
    for(j=0; j<precurserBitstringCounter; j++) {
      tmpBitstrings[j] = precurserBitstrings[j]+pow(2,pow(2,i))*precurserBitstrings[j];
      //printf("added precurser=");
      //printBinary(tmpBitstrings[j], T);
      tmpBitstrings[j+precurserBitstringCounter] = precurserBitstrings[j]+((long)(pow(2,pow(2,i))*(precurserBitstrings[j]))^mask);
      //printf("!!added precurser=");
      //printBinary(tmpBitstrings[j+precurserBitstringCounter], T);
    }
    tmpBitstrings[2*precurserBitstringCounter] = (long)((tmpBitstrings[2])^((long)(mask/pow(2,pow(2,i)))));
    //printf("!added precurser=");
    //printBinary(tmpBitstrings[2*precurserBitstringCounter], T);
    precurserBitstringCounter = pow(2,i+2)-1;
    memcpy(precurserBitstrings,tmpBitstrings,precurserBitstringCounter*sizeof(unsigned long));
  }

  int bitstringCounter = 1;  // bitstringCounter starts at 1 since 0 is the given bitstring

  mask = mask+mask/pow(2,pow(2,K-1));
  for(i=0; i<2*T-1; i++) {
    stabStateIndices[bitstringCounter] = given^(precurserBitstrings[i]^((long)mask));
    //stabStateIndices[bitstringCounter] = given^(precurserBitstrings[i]);
    //printf("new bitstring=");
    //printBinary(stabStateIndices[bitstringCounter], T);
    bitstringCounter++;
    if(bitstringCounter > bitstringCounterMax) return;
  }

}


int main(int argc, char *argv[])
{

  int T = (int)pow(2,4);
  long* stabStateIndices;
  
  stabStateIndices = calloc(2*T+1,sizeof(long));

  stabStateIndices[0] = (int)(pow(2,T))-1;

  printBinary(stabStateIndices[0],T);
  printf("!!\n");

  supplement2(&stabStateIndices[0], T, 1.0);

  int i;
  for(i=0; i<2*T; i++)
    printBinary(stabStateIndices[i], T);
  printf("\n");

  free(stabStateIndices);
  
  return 0;
  
}
