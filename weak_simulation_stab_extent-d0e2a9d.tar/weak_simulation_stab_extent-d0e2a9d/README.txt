Weak simulation of multi-Pauli measurements using approximate correlated stabilizer state decompositions
-------------------------------------------------------------------------------------------------------

See the draft at [https://arxiv.org/abs/XXXXXX] for an introduction and description of this code. The uncorrelated version is described in [PRX QUANTUM 2, 010345 (2021)] by Seddon, Regula, Pashayan, Ouyang, Campbell (SRPOC).

Note: the correlated sampling is currently only implemented for a maximum of 2t-1 supplemental correlated states!

Note: The stabilizer state representation used in this does not use the CH-form, which ostensibly will speed up simulations here by a factor of approximately 50. We use the implementation described in the Supporting Information of arXiv:1601.07601. A 50-fold improvement is described in arXiv:1808.00128v2.

PREREQUISITES:

You will need the openMP library to run weaksim.c (in particular, the omp.h header).
For instance, in Debian, you can obtain this by running:
$ sudo apt install libomp-dev

BUILD:

1. We start with the code that scales quadratically with approximate stabilizer rank.
$ make weaksim

2. This produces libraries (*.so) of core functions like SHRINK, INNERPRODUCT, EXTEND, etc. since you might want to use them in other code. This means we need to put them somewhere the linker can find them. Follow 3a) for a temporary and easy method that will only be valid for the current shell session and follow 3b) for a persistent method that requires root access.

3a) Update LD_LIBRARY_PATH to see the library:
$ export LD_LIBRARY_PATH=$PWD:$LD_LIBRARY_PATH
or
3b) If you have root privileges put the *so library /usr/local/lib or whatever library directory in your path. Then, use ldconfig to write the path in the config file:
$ sudo cp ./*so /usr/local/lib
$ sudo echo "/usr/local/lib" >> /etc/ld.so.conf
$ sudo ldconfig

4. To run weaksim you need to specify how many parallel processors for openMP to use
a) if you have no hyperthreading
export OMP_NUM_THREADS=8
b) if you have hyperthreading
export OMP_PROC_BIND=true
export OMP_NUM_THREADS=8


5. Build code for generating random commuting Pauli inputs (necessary for the strongsim[1-12]_relerr.c code since it requires a Hermitian observable to get away with using the square root number of stabilizer states).
$ make randominputcommutingHermitianPauli2

6. Build Hilbert vector space code to check our results.
$ make multipauli

7. Run timing analysis for fixed t and delta
$ bash timing_t_enforceddelta.bash
Output will be in tmp_$[t]_t.txt for the correlated case and in tmp_$[t]_iid.txt for the i.i.d. case and provide the second-longest and longest runtime, and the largest error (closest to the target delta).

Details of source code files:

weaksim.c takes four arguments corresponding to the target additive error, the angle of the magic state, a "coherent sampling" flag to indicate whether sampling should be correlated and if so how many maximal supplemental states to use (0=no; 1=t; 2=2t-1; 3=xi^3t/2), a seed to use for the i.i.d. random stabilizer state sampling. There is also an optional argument for the "sample number prefactor" which only takes the corresponding fraction of supplemental states indicated by the "coherent sampling" flag, i.e. if you want 0.5 t supplemental states then this argument should be 0.5 and the "coherent sampling" should be 1.

weaksim_relerr.c is a prototype function that also uses random stabilizer state sampling to calculate outcome probabilities from the Haar measure. This is still in a beta stage.

randominputcommutingHermitianPauli.c uses a brute-force random sampling of the commuting Paulis whereas *2.c uses random Clifford operations on initially separable Paulis to generate the commuting Paulis. *2.c is the only practically viable method for more than 30 Paulis on a desktop computer.

NOTE: current strongsim*c only support the same number of T gates as number of qubits!

Pd.txt is a tabulated list of P(d) values for strongsim[1-12]_relerror.c.
