#!/bin/bash
# Bash script to get some timing analysis

# Runtime for different t's

# number of runs to run in parallel
maxthreads=10
# NOTE: that this is not the same as running weaksim in parallel! For that you need to set OMP_NUM_THREADS appropriately (see README.txt)
# Note that setting OMP_NUM_THREADS>1 will lead to more pessimistic runtime analysis, due to parallelization overhead, though the runs should complete faster!

## For the most accurate time analysis, run with
## export OMP_NUM_THREADS=1
## export OMP_PROC_BIND=false
#export OMP_NUM_THREADS=6
#export OMP_PROC_BIND=true
export OMP_NUM_THREADS=1
export OMP_PROC_BIND=false

delta=0.1
deltasquared=`bc -l <<< $delta^2`

numruns=10 #1000

#for t in 4 8
for t in 8
#for t in 16
#for t in 32
#for t in 2 4 8 #16 #32
#for t in 8 16 32
do
    #delta=`bc -l <<< 10^-$deltapower`
    echo "t=$t"
    # alpha is the fraction of t supplemental states that we will take to keep the cost the same
    # alpha = delta*xi^t/t
    #echo "0.25*$delta*1.17^$t/$t"
    #alpha=`bc -l <<< 0.25*$delta*1.17^$t/$t`
    #%echo "alpha=$alpha"
    TIMEFORMAT='%3R';
    #number of runs
    for (( i=1; i<=$numruns; i++ ))
    do
    	# Generate two t-Pauli measurements
    	./randominputcommutingHermitianPauli2 $t $t 1000 | head -n $[2*$t+4] > inputPauli_$[i].txt
    	sleep 1
    done
    for (( i=1; i<=$numruns; i++ ))
    do
    	# Exact measurements
    	./multipauli < inputPauli_$[i].txt | tail -1 | cut -d ' ' -f 1 > tmp_$[t]_exact_$[i].txt &
    	#seed=`od -A n -t d -N 4 /dev/urandom |tr -d ' '|tr -d '-'`
    	#./weaksim 0.001 0.25 2 $seed < inputPauli_$[i].txt | tail -1 | cut -d ' ' -f 3 > tmp_$[t]_exact_$[i].txt &
    	#./weaksim 0.01 0.25 2 $seed < inputPauli_$[i].txt | tail -1 | cut -d ' ' -f 3 > tmp_$[t]_exact_$[i].txt &
    	# minus one below so as not to count grep search job
    	numthreads=$[`ps -aux | grep multipauli | wc -l`-1]
    	#numthreads=$[`ps -aux | grep weaksim | wc -l`-1]
    	while [ $numthreads -gt $[$maxthreads-1] ]
    	do
    	    sleep 10
    	    numthreads=$[`ps -aux | grep multipauli | wc -l`-1]
    	    #numthreads=$[`ps -aux | grep weaksim | wc -l`-1]
    	done
    done
    
    for (( i=1; i<=$numruns; i++ ))
    do
	echo "run: $i"
	
	approxerror=1.0
	approxcoherror=1.0

	samplePrefactor=0.001
	seed=`od -A n -t d -N 4 /dev/urandom |tr -d ' '|tr -d '-'`
	while (( $(echo "$approxerror > $deltasquared" |bc -l) )); do
	    echo "samplePrefactor=$samplePrefactor"
	    ( time ( ./weaksim $delta 0.25 0 $seed $samplePrefactor < inputPauli_$[i].txt >> tmp_$[t]_iid_$[i].txt ) ) 2> tmp_$[t]_iid_$[i]_timing.txt

	    exactanswer=`tail -1 tmp_$[t]_exact_$[i].txt`
	    approxanswer=`tail -1 tmp_$[t]_iid_$[i].txt | cut -d ' ' -f 3`
	    approxerror=`bc -l <<< "sqrt(($exactanswer-$approxanswer)^2)"`
	    echo $approxerror
	    samplePrefactor=`bc -l <<< "scale=4;($samplePrefactor*1.1)/1"`
 	done
	samplePrefactor=`bc -l <<< "scale=4;($samplePrefactor/1.1)/1"`
	echo "samplePrefactor used=$samplePrefactor"
	echo $approxerror >> tmp_$[t]_iid_$[i]_error.txt

	samplePrefactor=0.001
	while (( $(echo "$approxcoherror > $deltasquared" |bc -l) )); do
	    echo "samplePrefactor=$samplePrefactor"
	    ( time ( ./weaksim $delta 0.25 2 $seed $samplePrefactor < inputPauli_$[i].txt >> tmp_$[t]_t_$[i].txt ) ) 2> tmp_$[t]_t_$[i]_timing.txt

	    exactanswer=`tail -1 tmp_$[t]_exact_$[i].txt`
	    approxcoherentanswer=`tail -1 tmp_$[t]_t_$[i].txt | cut -d ' ' -f 3`
	    approxcoherror=`bc -l <<< "sqrt(($exactanswer-$approxcoherentanswer)^2)"`
	    echo $approxcoherror
	    samplePrefactor=`bc -l <<< "scale=4;($samplePrefactor*1.1)/1"`
	done
	samplePrefactor=`bc -l <<< "scale=4;($samplePrefactor/1.1)/1"`
	echo "samplePrefactor used=$samplePrefactor"
	echo $approxcoherror >> tmp_$[t]_t_$[i]_error.txt

    done

    for (( i=1; i<=$numruns; i++ ))
    do
	rm tmp_$[t]_exact_$[i].txt;
	rm tmp_$[t]_iid_$[i].txt;
	rm tmp_$[t]_t_$[i].txt;
	rm inputPauli_$[i].txt;
	#echo "*******************" >> tmp_$[t]_iid.txt
	#echo "*******************" >> tmp_$[t]_t.txt
	#   sleep 1
    done
    echo "Longest runtime:" >> tmp_$[t]_iid.txt
    cat tmp_$[t]_iid_[1-9]*_timing.txt | sort -n | tail -2 >> tmp_$[t]_iid.txt
    rm tmp_$[t]_iid_[1-9]*_timing.txt
    echo "Longest runtime:" >> tmp_$[t]_t.txt
    cat tmp_$[t]_t_[1-9]*_timing.txt | sort -n | tail -2 >> tmp_$[t]_t.txt
    rm tmp_$[t]_t_[1-9]*_timing.txt
    echo "Largest error:" >> tmp_$[t]_iid.txt
    cat tmp_$[t]_iid_[1-9]*_error.txt | sort -n | tail -1 >> tmp_$[t]_iid.txt
    rm tmp_$[t]_iid_[1-9]*_error.txt
    echo "Largest error:" >> tmp_$[t]_t.txt
    cat tmp_$[t]_t_[1-9]*_error.txt | sort -n | tail -1 >> tmp_$[t]_t.txt
    rm tmp_$[t]_t_[1-9]*_error.txt
    echo "delta=$delta done!"
done
