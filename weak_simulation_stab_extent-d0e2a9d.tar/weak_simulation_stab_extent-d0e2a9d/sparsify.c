#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <complex.h>

#include "matrix.h"
#include "supplement.h"
#include "supplement2.h"
#include "sparsify.h"

/****************************************************************************
 * SPARSIFY procedure introduced by Bravyi et al. 
 * (S. Bravyi, D. Browne, P. Calpin, E. Campbell, D. Gosset, and
 * M. Howard, Simulation of Quantum Circuits by Low-Rank Sta-
 * bilizer Decompositions, Quantum 3, 181 (2019).)
 * Outputs stabilizer state indices in stabStateIndices
 * as understood by weaksim.c in the tilde'd "computational" basis.
 ***Needs address of stabStateIndices since it allocates it.***
 * 'numStabStates' is the number of stabilizer state indices,
 * 'T' is the number of T-gate magic states, 'phi' is the angle of the
 * intermediate diagonal magic state, and 'delta' is the additive
 * error of the state.
 * For phi=pi/4 this should give you a uniform distro over [0,2^T-1].
 ****************************************************************************/

// Note: Make sure you seed the random number generator before calling this!
// i.e. srand((unsigned)time(NULL));
int sparsify(long **stabStateIndices, int *numStabStates, int T, double phi, double delta, int coherentSampling, double samplePrefactor) {

  int i, j, k, l;

  double L1Norm = pow(sqrt(1-sin(phi)) + sqrt(1-cos(phi)),T);
  //printf("L1Norm squared (= stabilizer extent) = %lf\n", pow(L1Norm,2.0));

  // fraction of optimal T supplemental states
  //double alpha = 2.0*sqrt(2.0)*delta*pow(L1Norm,2.0)/((double)T);
  //double alpha = 2.0*sqrt(2.0)*delta*pow(L1Norm,2.0)/(4.0+pow(delta,2.0))/((double)T);
  double alpha; 

  // fraction of T supplemental states that we actually need for optimal scaling
  // if first term is kept from Seddon et al.
  //double fractionSupplement = alpha*0.25*delta*pow(L1Norm,2.0)/((double)T);
  // if first term isn't kept
  double fractionSupplement;

  printf("delta = %lf\n", delta);

  printf("L1Norm = %lf\n", L1Norm);

  double gamma;
  int increment;

  if(coherentSampling!=0) {
    if(coherentSampling==2) {
      alpha = 10.0*pow(delta,2.0)*1.0*pow(L1Norm,2.0)/delta/((double)(2*T-1));
      fractionSupplement = alpha*1.0;
      *numStabStates = ceil(samplePrefactor*0.05*pow(L1Norm,2.0)/delta/((double)(floor(fractionSupplement*(2*T-1))+1)))*(floor(fractionSupplement*(2*T-1))+1);
      increment = floor(fractionSupplement*(2*T-1))+1;
    } else if(coherentSampling==1) {
      alpha = 10.0*pow(delta,2.0)*1.0*pow(L1Norm,2.0)/delta/((double)(T));
      fractionSupplement = alpha*1.0;
      *numStabStates = ceil(samplePrefactor*0.05*pow(L1Norm,2.0)/delta/((double)(floor(fractionSupplement*(T))+1)))*(floor(fractionSupplement*(T))+1);
      increment = floor(fractionSupplement*(T))+1;
    }
    
    printf("Performing coherent sampling!\n");
    printf("Using an optimal fraction of T supplemental states!\n");
    printf("Optimal fraction = %lf\n", fractionSupplement);
    // since we will be taking a multiple of (fractionSupplement*T+1) samples, we round numStabStates up to the nearest multiple of (fractionSupplement*T+1)
    // if first term is kept from Seddon et al.
    //*numStabStates = ceil((8.0/(8.0*delta-sqrt(2.0)*sqrt(16.0-16.0*alpha+pow(alpha,3.0)*pow(delta,4.0))))*pow(L1Norm,2.0)/((double)(ceil(fractionSupplement*T)+1)))*(ceil(fractionSupplement*T)+1);
    // if first term isn't kept
    //*numStabStates = ceil(0.0005*(sqrt(2.0)*pow(L1Norm,2.0)/delta-0.5*fractionSupplement*T/pow(delta,2.0)+pow(fractionSupplement*T/L1Norm,2.0)/8.0/sqrt(2.0)/pow(delta,3.0))/((double)(ceil(fractionSupplement*T)+1)))*(ceil(fractionSupplement*T)+1);
    //*numStabStates = ceil(sqrt(2.0)*(2.0+pow(delta,2.0))*pow(L1Norm,2.0)/delta/(4.0+pow(delta,2.0))/((double)(ceil(fractionSupplement*T)+1)))*(ceil(fractionSupplement*T)+1);

    printf("increment= %d\n", increment);
    //printf("prebinned numStabStates=%d\n", (int)ceil((8.0/(8.0*delta-sqrt(2.0)*sqrt(16.0-16.0*alpha+pow(alpha,3.0)*pow(delta,4.0))))*pow(L1Norm,2.0)));
    //printf("prebinned numStabStates=%d\n", (int)ceil(0.0005*(sqrt(2.0)*pow(L1Norm,2.0)/delta-0.5*fractionSupplement*T/pow(delta,2.0)+pow(fractionSupplement*T/L1Norm,2.0)/8.0/sqrt(2.0)/pow(delta,3.0))));
    //printf("prebinned numStabStates=%d\n", (int)ceil(sqrt(2.0)*(2.0+pow(delta,2.0))*pow(L1Norm,2.0)/delta/(4.0+pow(delta,2.0))));
    printf("prebinned numStabStates=%d\n", (int)ceil(samplePrefactor*0.05*pow(L1Norm,2.0)/delta));
    fflush(stdout);
    if(fractionSupplement > 1.0) {
      printf("Too many supplemental states requested!\n");
      printf("Note: the correlated sampling is currently only implemented for a maximum of (2t-1) supplemental correlated states!\n");
      return 1;
    }
  } else if(coherentSampling==0) {
    //gamma = 1.0 + (1.0 - 1.0/pow(2.0,0.02*T))*T;
    // SPARSIFY
    //*numStabStates = ceil(((pow(L1Norm,2.0)-gamma)/pow(delta,2.0))/((double)(T+1)))*(T+1);
    // if first term is kept from Seddon et al.
    //*numStabStates = ceil((2.0+sqrt(2.0))*(pow(L1Norm,2.0))/pow(delta,1.0));
    // if first term isn't kept
    *numStabStates = ceil(samplePrefactor*(1.0*2.0+sqrt(2.0))*(pow(L1Norm,2.0))/pow(delta,1.0));
    // multiply the factor of 2.0 by 1.0 to get the prior state-of-the-art
    // multiply the factor of 2.0 by 0.0 to get the tighter bound on the prior state-of-the-art
    increment = 1;
  } else {
    printf("Error: Unknown value for \"coherent sampling\" flag");
    return 1;
  }


  printf("numStabStates = %d\n", *numStabStates);
  fflush(stdout);
  
  double cumL1Norm, sum;
  long index, tmpIndex;
  int shiftCounter, digit;

  *stabStateIndices = calloc(*numStabStates,sizeof(long));

  for(i=0; i<*numStabStates; i=i+increment) {
    // We will pick our stabilizer index by first selecting how many tilde'd 1s it will have
    // by randomly sampling weighted by the binomial expansion of that in the L1norm,
    // and then uniformly randomly picking which digits to make that many tilde 1's
    
    // Get random number and scale by the L_1 norm of the t-qubit full stabilizer decomposition
    cumL1Norm = ((((double)rand())/((double)(RAND_MAX)))*L1Norm); // this is the "cumulative" L1 norm of the randomly selected state if you index by the tilde'd computational basis states truncated to an integer
    sum = 0.0;
    //printf("%d cumL1Norm = %lf\n", i, cumL1Norm);
    for(j=T; j>=0; j--) {
      // add cumulative L1 norm to sum until you are greater than cumL1Norm of random state
      //printf("binomcoeff(%d,%d)=%lf\n", T, j, binomcoeff(T,j));
      if(j < T)
	sum += binomcoeff(T,j)*(sqrt(1.0-cos(phi)))*pow(sqrt(1.0 - cos(0.25*PI)),T-1-j)*pow(sqrt(1.0-sin(phi)),j);
      else 
	sum += pow((sqrt(1.0-sin(phi))),T);
      //printf("%d sum=%lf\n", j, sum);
      if(cumL1Norm <= sum) {
	// the randomly chosen tilde'd computational state will have j tilde'd 1s
	// Now uniformly randomly choose a state with j tilde'd 1s
	//printf("%d tilde'd ones\n", (T-j));
	index = 0;
	for(k=0; k<(T-j); k++) {
	  digit = (int)((((double)rand())/((double)(RAND_MAX)))*(T-k));
	  //printf("digit=%d\n", digit);
	  tmpIndex = index;
	  shiftCounter = 0;
	  // first shift past leading 1's
	  while(tmpIndex%2 == 1) {
	    tmpIndex /= 2; // keep shifting to the left past any 1's that have already been assigned
	    shiftCounter++;
	  }
	  // now shift past 'digit' 0's
	  for(l=0; l<digit; l++){
	    tmpIndex /= 2; // shift to the left by one (base 2 arithmetic)
	    shiftCounter++;
	    while(tmpIndex%2 == 1) {
	      tmpIndex /= 2; // keep shifting to the left past any 1's that have already been assigned
	      shiftCounter++;
	    }
	  }
	  //printf("shiftCounter = %d\n", shiftCounter);
	  index += pow(2,shiftCounter);
	}
	(*stabStateIndices)[i] = index;
	//printf("first index = %d\n", index);
	if(coherentSampling==2)
	  //for(k=1; k<=T; k++)
	    //(*stabStateIndices)[i+k] = index ^ (long)pow(2,k-1); // flip the (k-1)th bit index
	  supplement2(&(*stabStateIndices)[i], T, fractionSupplement);
	else if(coherentSampling==1)
	  //for(k=1; k<=T; k++)
	    //(*stabStateIndices)[i+k] = index ^ (long)pow(2,k-1); // flip the (k-1)th bit index
	  supplement(&(*stabStateIndices)[i], T, fractionSupplement);
	break;
      }
      //printf("%lf\n", sum);
    }
    //printf("index:%ld\n ", index);
    //printf("(*stabStateIndices)[%d]:%ld\n ", i, (*stabStateIndices)[i]);
  }
  //printf("\n");

  return 0;
    
}

// binomial coefficient
double binomcoeff(int m, int n) {
  //((double)fac(T))/((double)(fac(j)*fac(T-j)))
  int i;
  double coeff = 1.0;
  if (n<=m) {
    for(i=n+1;i<=m;i++) {
      coeff *= (double)i/((double)i-n);
      //printf("%lf ", coeff);
    }
    //printf("\n");
    return coeff;
  }
  else
    return 1;
}
