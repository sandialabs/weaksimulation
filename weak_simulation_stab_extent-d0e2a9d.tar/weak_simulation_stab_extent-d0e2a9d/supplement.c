#include <stdio.h>
#include <stdlib.h>
#include <math.h>


void printBinary(unsigned long number, int T) {

  int i;
  
  for(i=0; i<T; i++)
    printf("%d", (int)(number/pow(2,i))%2);
  printf("\n");
  
}

void supplement(long stabStateIndices[], int T, double fractionSupplement)
{

  int K = round(log(T)/log(2)); // T = 2^K

  //printf("K=%d\n", K);

  int treeDepth, levelMaskDepth, maskIndex;

  unsigned long levelMask;

  unsigned long long maskList[K];

  unsigned long given = (unsigned long)stabStateIndices[0]; // the given bitstring

  unsigned long bitstring;

  int bitstringCounter = 1;  // bitstringCounter starts at 1 since 0 is the given bitstring
  int bitstringCounterMax = floor(fractionSupplement*T);

  int i;

  if(bitstringCounter > bitstringCounterMax) return;

  // first added bitstring is alpha ... alpha for alpha = 01
  bitstring = 1;
  for(i=1; i<T/2; i++) {
    bitstring *= 4;
    bitstring += 1;
  }
  //printf("%lu\n", bitstring);
  stabStateIndices[bitstringCounter] = given^(bitstring);
  bitstringCounter++;
  if(bitstringCounter > bitstringCounterMax) return;

  // second added bitstring is beta ... beta for beta = 10
  bitstring = 2;
  for(i=1; i<T/2; i++) {
    bitstring *= 4;
    bitstring += 2;
  }
  //printf("%lu\n", bitstring);
  stabStateIndices[bitstringCounter] = given^bitstring;
  bitstringCounter++;
  if(bitstringCounter > bitstringCounterMax) return;

  maskList[0] = round(pow(2,pow(2,K)))-1;

  for(treeDepth=1; treeDepth<=K-1; treeDepth++) {

    levelMask = round(pow(2,pow(2,K-treeDepth))-1);
    // repeat this unit-cell mask to the other bits on levelMask
    for(levelMaskDepth=2; levelMaskDepth<=round(pow(2,treeDepth-1)); levelMaskDepth++) {
      levelMask += round(pow(2,pow(2,K-treeDepth+1)))*levelMask;
    }

    //printf("levelMask=");
    //printBinary(levelMask, T);

    bitstring = stabStateIndices[1] ^ levelMask;

    for(maskIndex=0; maskIndex < (int)(pow(2,treeDepth)); maskIndex++) {
      stabStateIndices[bitstringCounter] = bitstring;
      for(i=0; i<treeDepth; i++){
	// if ith binary digit of maskIndex is 1 then XOR with ith string in maskList
	stabStateIndices[bitstringCounter] ^= ((int)(maskIndex/(pow(2,i)))%2)*maskList[i];
      }
      //printf("new bitstring=");
      //printBinary(stabStateIndices[bitstringCounter], T);
      bitstringCounter++;
      if(bitstringCounter > bitstringCounterMax) return;
    }

    maskList[treeDepth] = levelMask;
    
  }
    
}


int main(int argc, char *argv[])
{

  int T = (int)pow(2,4);
  long* stabStateIndices;
  
  stabStateIndices = calloc(T+1,sizeof(long));

  stabStateIndices[0] = (int)(pow(2,T))-1;

  supplement(&stabStateIndices[0], T, 1.0);

  int i;
  for(i=0; i<T+1; i++)
    printBinary(stabStateIndices[i], T);
  printf("\n");
  
  return 0;
  
}
