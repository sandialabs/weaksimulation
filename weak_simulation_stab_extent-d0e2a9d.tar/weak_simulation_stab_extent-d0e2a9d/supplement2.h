void supplement2(long stabStateIndices[], int T, double fractionSupplement);
void printBinary(unsigned long number, int T);
