void supplement(long stabStateIndices[], int T, double fractionSupplement);
void printBinary(unsigned long number, int T);
