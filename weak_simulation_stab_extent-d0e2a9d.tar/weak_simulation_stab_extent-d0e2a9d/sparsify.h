#define PI 3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679

double binomcoeff(int m, int n);
int sparsify(long** stabStateIndices, int* numStabStates, int T, double phi, double delta, int coherentSampling, double samplePrefactor);
